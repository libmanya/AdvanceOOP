#ifndef __DIRECTION__H_
#define __DIRECTION__H_

enum class Direction
{
    East, West, South, North, Stay
};

#endif //__DIRECTION__H_
